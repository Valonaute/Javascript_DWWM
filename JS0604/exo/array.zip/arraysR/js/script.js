const exerciceA = document.getElementById("exerciceA");
const exerciceB = document.getElementById("exerciceB");
const exerciceC = document.getElementById("exerciceC");
const enonce = document.getElementById("enonce");
/**Créez la fonction soustraction(nombre1, nombre2), prenant donc deux nombres en argument et qui retourne la soustraction de ces 2 nombres. Testez votre fonction en affichant son résultat. */
exerciceA.innerHTML += "<h3>Exercice 1.</h3>";




/**Créez un tableau qui contient quatre éléments de votre choix. Afficher le second élément du tableau */
exerciceA.innerHTML += "<h3>Exercice 2.</h3>";




/**Utilisez maintenant une boucle pour afficher tout le contenu du tableau. */
exerciceA.innerHTML += "<h3>Exercice 3.</h3>";




/**Créez une fonction lectureTableau(tableau) qui prend un tableau en argument et qui en affiche tout le contenu à l'aide d'une boucle.*/
exerciceA.innerHTML += "<h3>Exercice 4.</h3>";


