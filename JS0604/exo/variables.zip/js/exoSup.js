/*Créez deux variables contenant des nombres. Déclarer une variable resultat qui contiendra la somme de ces variables, affichez cette variable via console.log(), document.write() ou alert()*/
//pour ecrire dans l'aside exerciceA: copier le code ci dessous et changer la chaîne de caractères
 ecrire("<h3>Basique</h3>");

 /*Affichez le resultat de la soustraction, de la multiplication, de la division et du modulo des deux variables
*/

/*Affichez "la variable [nom de votre première variable] contient : [valeur de votre variable] dans la console ou le document
*/

/**A partir de deux variables contenant les string "hello" et "world", affichez "Hello world".
 **/



/**Exercices Intermédiaires**/
//Pour écrire dans l'aside exerciceB: copier le code ci dessous et changer la PREMIERE chaîne de caractères

ecrire("<h3>Intermédiaire</h3>", "b");

/**Créez deux variables contenant deux valeurs numériques et une variable resultatB. Créez une dernière variable qui contiendra la phrase "[valeur de la première variable] + [valeur de la seconde variable] = [valeur de la variable resultatB]. Affichez cette variable
 */

/**Créez deux variables et inversez leurs valeurs (la valeur de la 1ere variable devient la valeur de la 2nde et inversement
 */

    
/**Créez une variable de type nombre, verifiez son type grace à la fonction typeof() dans un console.log() Changez le type de la variable en string via la fonction String(). Refaites un typeof() pour constater le changement.*/

