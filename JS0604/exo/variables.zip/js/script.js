/*Variables à déclarer : 
nom ============= string(chaîne de caractères)
prenom ========== string(chaîne de caractères)
job ============= string(chaîne de caractères)
age ============= integer(nombre entier)
working ========= boolean(opérateur booleen)
/** */


//ecrasez les variables pour présenter un second personnage en changeant toutes les valeurs

//Ajoutez deux ans à votre second personnage sans ecraser de variables ni coder en dur

//Calculez la moyenne d'âge de vos deux personnages dans une variable nommée resultat










/** Options **/

//Faites apparaître les deux fiches personnages sur cette page avec une création d'éléments


//Utilisez un objet plutôt que des variables libres


//Généralisez la création de fiches personnage avec une fonction


//Automatisez la création de fiches avec une boucle